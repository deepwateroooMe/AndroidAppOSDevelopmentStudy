﻿using strange.extensions.command.impl;
using strange.extensions.context.api;
using UnityEngine;

/// <summary>
/// 程序启动命令.
/// </summary>
public class StartUpCommand : EventCommand
{
    [Inject(ContextKeys.CONTEXT_VIEW)]
    public GameObject contextView { get; set; }

    public override void Execute()
    {
        //获取 UI 画布
        Transform canvas = contextView.transform.FindChild("Canvas");
        //加载并添加 MainUI
        GameObject go = Resources.Load("Prefabs/MainUI", typeof(GameObject)) as GameObject;
        GameObject mainUI = GameObject.Instantiate(go) as GameObject;
        //添加视图脚本, 或者直接绑定到预制件中都可以
        mainUI.AddComponent<MainUIView>();
        mainUI.transform.SetParent(canvas, false);
    }
}

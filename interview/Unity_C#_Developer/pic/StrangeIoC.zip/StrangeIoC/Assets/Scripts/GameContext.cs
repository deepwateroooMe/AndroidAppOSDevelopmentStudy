﻿using strange.extensions.context.api;
using strange.extensions.context.impl;
using UnityEngine;

/// <summary>
/// 游戏上下文.
/// </summary>
public class GameContext : MVCSContext
{
    public GameContext () : base()
    {
    }

    public GameContext(MonoBehaviour view, bool autoStartup) : base(view, autoStartup)
    {
    }

    protected override void mapBindings()
    {
        mapModel();
        mapView();
        mapController();

        //调用 StartUp 命令启动程序
        commandBinder.Bind(ContextEvent.START).To<StartUpCommand>().Once();
    }

    /// <summary>
    /// 映射模型.
    /// </summary>
    private void mapModel()
    {
        injectionBinder.Bind<IMainUIService>().To<MainUIService>().ToSingleton();
        injectionBinder.Bind<IMainUIModel>().To<MainUIModel>().ToSingleton();

        injectionBinder.Bind<ISkillService>().To<SkillService>().ToSingleton();
        injectionBinder.Bind<ISkillModel>().To<SkillModel>().ToSingleton();
    }

    /// <summary>
    /// 映射视图.
    /// </summary>
    private void mapView()
    {
        mediationBinder.Bind<MainUIView>().To<MainUIMediator>();

        mediationBinder.Bind<SkillUIView>().To<SkillUIMediator>();
    }

    /// <summary>
    /// 映射控制器.
    /// </summary>
    private void mapController()
    {
        commandBinder.Bind(NotificationCenter.OPEN_SKILL_UI).To<OpenSkillUICommand>();
        commandBinder.Bind(NotificationCenter.CLOSE_SKILL_UI).To<CloseSkillUICommand>();
        commandBinder.Bind(NotificationCenter.SEND_MSG_TO_SKILL_UI).To<SendMsgToSkillUICommand>();

        commandBinder.Bind(NotificationCenter.SKILL_REQUEST).To<SkillRequestCommand>();
    }
}

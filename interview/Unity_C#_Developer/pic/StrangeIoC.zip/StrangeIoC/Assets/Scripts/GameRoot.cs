﻿using strange.extensions.context.impl;

/// <summary>
/// 游戏根容器类.
/// </summary>
public class GameRoot : ContextView
{
    void Awake()
    {
        //创建游戏上下文对象并启动
        context = new GameContext(this, true);
        context.Start();
    }
}

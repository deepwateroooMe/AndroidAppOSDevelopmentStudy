﻿using strange.extensions.command.impl;
using strange.extensions.context.api;
using UnityEngine;

public class CloseSkillUICommand : EventCommand
{
    [Inject(ContextKeys.CONTEXT_VIEW)]
    public GameObject contextView { get; set; }

    public override void Execute()
    {
        //获取 UI 画布
        Transform canvas = contextView.transform.FindChild("Canvas");
        //销毁技能面板
        Transform skillUI = canvas.FindChild("SkillUI(Clone)");
        if(skillUI != null)
        {
            GameObject.Destroy(skillUI.gameObject);
        }
    }
}

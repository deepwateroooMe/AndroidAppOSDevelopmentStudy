﻿using strange.extensions.command.impl;
using strange.extensions.context.api;
using UnityEngine;

public class OpenSkillUICommand : EventCommand
{
    [Inject(ContextKeys.CONTEXT_VIEW)]
    public GameObject contextView { get; set; }

    public override void Execute()
    {
        //获取 UI 画布
        Transform canvas = contextView.transform.FindChild("Canvas");
        Transform skillUIT = canvas.FindChild("SkillUI(Clone)");
        if(skillUIT != null)
        {
            return;
        }
        //加载并添加 SkillUI
        GameObject go = Resources.Load("Prefabs/SkillUI", typeof(GameObject)) as GameObject;
        GameObject skillUI = GameObject.Instantiate(go) as GameObject;
        //添加视图脚本, 或者直接绑定到预制件中都可以
        skillUI.AddComponent<SkillUIView>();
        skillUI.transform.SetParent(canvas, false);
    }
}

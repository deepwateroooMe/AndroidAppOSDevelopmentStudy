﻿using strange.extensions.command.impl;
using UnityEngine;

public class SendMsgToSkillUICommand : EventCommand
{
    public override void Execute()
    {
        MainUIMsgVO vo = (MainUIMsgVO)evt.data;
        Debug.Log("Command获取到发送的消息: " + vo.msg);

        dispatcher.Dispatch(NotificationCenter.SKILL_UI_ADD_MSG, vo.msg);
    }
}

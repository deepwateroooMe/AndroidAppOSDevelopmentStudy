﻿using strange.extensions.dispatcher.eventdispatcher.api;
using strange.extensions.mediation.impl;

/// <summary>
/// 主界面中介类.
/// </summary>
public class MainUIMediator : EventMediator
{
    [Inject]
    public MainUIView view { get; set; }

    public override void OnRegister()
    {
        view.dispatcher.AddListener(MainUIView.OPEN_SKILL_UI_CLICK, OpenSkillUIClickHandler);
        view.dispatcher.AddListener(MainUIView.CLOSE_SKILL_UI_CLICK, CloseSkillUIClickHandler);
        view.dispatcher.AddListener(MainUIView.SEND_MSG_TO_SKILL_UI_CLICK, SendMSGToSkillUIClickHandler);

        view.Init();
    }

    public override void OnRemove()
    {
        view.dispatcher.RemoveListener(MainUIView.OPEN_SKILL_UI_CLICK, OpenSkillUIClickHandler);
        view.dispatcher.RemoveListener(MainUIView.CLOSE_SKILL_UI_CLICK, CloseSkillUIClickHandler);
        view.dispatcher.RemoveListener(MainUIView.SEND_MSG_TO_SKILL_UI_CLICK, SendMSGToSkillUIClickHandler);
    }

    private void OpenSkillUIClickHandler(IEvent evt)
    {
        dispatcher.Dispatch(NotificationCenter.OPEN_SKILL_UI);
    }

    private void CloseSkillUIClickHandler(IEvent evt)
    {
        dispatcher.Dispatch(NotificationCenter.CLOSE_SKILL_UI);
    }

    private void SendMSGToSkillUIClickHandler(IEvent evt)
    {
        dispatcher.Dispatch(NotificationCenter.SEND_MSG_TO_SKILL_UI, evt.data);
    }
}

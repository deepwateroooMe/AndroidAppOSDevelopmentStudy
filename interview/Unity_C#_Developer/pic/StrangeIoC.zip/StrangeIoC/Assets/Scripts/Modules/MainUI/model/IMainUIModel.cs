﻿public interface IMainUIModel
{
    
}

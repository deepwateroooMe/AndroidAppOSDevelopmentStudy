﻿public interface IMainUIService
{
    
}

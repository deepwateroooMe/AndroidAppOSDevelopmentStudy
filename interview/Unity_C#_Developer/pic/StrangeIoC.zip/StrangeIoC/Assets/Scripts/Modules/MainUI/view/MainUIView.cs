﻿using strange.extensions.dispatcher.eventdispatcher.api;
using strange.extensions.mediation.impl;
using UnityEngine.UI;

/// <summary>
/// 主界面视图脚本.
/// </summary>
public class MainUIView : View
{
    public const string OPEN_SKILL_UI_CLICK = "openSkillUIClick";
    public const string CLOSE_SKILL_UI_CLICK = "closeSkillUIClick";
    public const string SEND_MSG_TO_SKILL_UI_CLICK = "sendMsgToSkillUIClick";

    [Inject]
    public IEventDispatcher dispatcher { get; set; }

    private Button openSkillUIBtn;
    private Button closeSkillUIBtn;
    private Button sendMsgToSkillUIBtn;

    public void Init()
    {
        openSkillUIBtn = this.gameObject.transform.FindChild("OpenSkillUIBtn").GetComponent<Button>();
        openSkillUIBtn.onClick.AddListener(OpenSkillUIBtnClickHandler);

        closeSkillUIBtn = this.gameObject.transform.FindChild("CloseSkillUIBtn").GetComponent<Button>();
        closeSkillUIBtn.onClick.AddListener(CloseSkillUIBtnClickHandler);

        sendMsgToSkillUIBtn = this.gameObject.transform.FindChild("SendMSGToSkillUIBtn").GetComponent<Button>();
        sendMsgToSkillUIBtn.onClick.AddListener(SendMsgToSkillUIBtnClickHandler);
    }

    private void OpenSkillUIBtnClickHandler()
    {
        dispatcher.Dispatch(OPEN_SKILL_UI_CLICK);
    }

    private void CloseSkillUIBtnClickHandler()
    {
        dispatcher.Dispatch(CLOSE_SKILL_UI_CLICK);
    }

    private void SendMsgToSkillUIBtnClickHandler()
    {
        dispatcher.Dispatch(SEND_MSG_TO_SKILL_UI_CLICK, new MainUIMsgVO {msg = "嗨，我是来自 MainUI 发送的消息！"});
    }
}

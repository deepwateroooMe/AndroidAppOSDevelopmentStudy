﻿public class MainUIMsgVO
{
    public string msg;
}

﻿using strange.extensions.command.impl;
using strange.extensions.dispatcher.eventdispatcher.api;

public class SkillRequestCommand : EventCommand
{
    [Inject]
    public ISkillModel model { get; set; }

    [Inject]
    public ISkillService service { get; set; }

    public override void Execute()
    {
        //这里有异步操作, 为了使 Command 对象不被释放, 我们需要调用下面的方法持有当前 Command 对象的引用
        Retain();

        service.dispatcher.AddListener(SkillService.RECEIVE_DATA, OnReceiveDataHandler);
        service.Request("http://www.game.com/mygame.php?id=1000");
    }

    private void OnReceiveDataHandler(IEvent evt)
    {
        service.dispatcher.RemoveListener(SkillService.RECEIVE_DATA, OnReceiveDataHandler);

        model.data = ((SkillMsgVO)evt.data).msg;
        dispatcher.Dispatch(NotificationCenter.SKILL_UI_ADD_MSG, model.data);

        //异步操作完成, 可以释放对象了
        Release();
    }
}

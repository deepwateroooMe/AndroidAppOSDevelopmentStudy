﻿using strange.extensions.dispatcher.eventdispatcher.api;
using strange.extensions.mediation.impl;

public class SkillUIMediator : EventMediator
{
    [Inject]
    public SkillUIView view { get; set; }

    public override void OnRegister()
    {
        dispatcher.AddListener(NotificationCenter.SKILL_UI_ADD_MSG, skillUIAddMsgHandler);

        view.dispatcher.AddListener(SkillUIView.REQUEST_BTN_CLICK, requestBtnClickHandler);

        view.Init();
    }

    public override void OnRemove()
    {
        dispatcher.RemoveListener(NotificationCenter.SKILL_UI_ADD_MSG, skillUIAddMsgHandler);

        view.dispatcher.RemoveListener(SkillUIView.REQUEST_BTN_CLICK, requestBtnClickHandler);
    }

    private void skillUIAddMsgHandler(IEvent evt)
    {
        view.AddText((string)evt.data);
    }

    private void requestBtnClickHandler(IEvent evt)
    {
        dispatcher.Dispatch(NotificationCenter.SKILL_REQUEST);
    }
}

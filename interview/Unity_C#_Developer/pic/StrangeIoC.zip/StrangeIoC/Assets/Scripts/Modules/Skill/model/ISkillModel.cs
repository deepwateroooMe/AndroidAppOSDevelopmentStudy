﻿public interface ISkillModel
{
    string data { get; set; }
}

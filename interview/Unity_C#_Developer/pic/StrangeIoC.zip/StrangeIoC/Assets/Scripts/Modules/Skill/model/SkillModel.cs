﻿public class SkillModel : ISkillModel
{
    public string data { get; set; }
}

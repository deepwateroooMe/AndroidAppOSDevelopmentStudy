﻿using strange.extensions.dispatcher.eventdispatcher.api;

public interface ISkillService
{
    IEventDispatcher dispatcher { get; set; }

    void Request(string url);
}

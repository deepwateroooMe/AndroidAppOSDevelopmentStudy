﻿using System.Collections;
using strange.extensions.context.api;
using strange.extensions.dispatcher.eventdispatcher.api;
using UnityEngine;

public class SkillService : ISkillService
{
    public const string RECEIVE_DATA = "receiveData";

    [Inject(ContextKeys.CONTEXT_VIEW)]
    public GameObject contextView { get; set; }

    [Inject]
    public IEventDispatcher dispatcher { get; set; }

    public void Request(string url)
    {
        contextView.GetComponent<GameRoot>().StartCoroutine(WaitASecond());
    }

    private IEnumerator WaitASecond()
    {
        yield return new WaitForSeconds(1.0f);

        dispatcher.Dispatch(RECEIVE_DATA, new SkillMsgVO{msg="我是服务端返回的数据！"});
    }
}

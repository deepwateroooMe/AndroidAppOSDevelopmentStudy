﻿using strange.extensions.dispatcher.eventdispatcher.api;
using strange.extensions.mediation.impl;
using UnityEngine.UI;

public class SkillUIView : View
{
    public const string REQUEST_BTN_CLICK = "requestBtnClick";

    [Inject]
    public IEventDispatcher dispatcher { get; set; }

    private Text outputText;
    private Button requestBtn;

    public void Init()
    {
        outputText = this.gameObject.transform.FindChild("OutputText").GetComponent<Text>();

        requestBtn = this.gameObject.transform.FindChild("RequestBtn").GetComponent<Button>();
        requestBtn.onClick.AddListener(RequestBtnClickHandler);
    }

    private void RequestBtnClickHandler()
    {
        dispatcher.Dispatch(REQUEST_BTN_CLICK);
    }

    public void AddText(string content)
    {
        outputText.text += content + "\n";
    }
}

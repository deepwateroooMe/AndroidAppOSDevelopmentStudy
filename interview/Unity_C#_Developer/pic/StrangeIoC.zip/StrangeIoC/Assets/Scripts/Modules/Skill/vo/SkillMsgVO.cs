﻿public class SkillMsgVO
{
    public string msg;
}

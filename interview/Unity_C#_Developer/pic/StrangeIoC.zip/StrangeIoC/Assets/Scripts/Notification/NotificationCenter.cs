﻿/// <summary>
/// 消息中心.
/// </summary>
public class NotificationCenter
{
    public const string OPEN_SKILL_UI = "openSkillUI";
    public const string CLOSE_SKILL_UI = "closeSkillUI";
    public const string SEND_MSG_TO_SKILL_UI = "sendMsgToSkillUI";

    public const string SKILL_REQUEST = "skillRequest";
    public const string SKILL_UI_ADD_MSG = "skillUIAddMsg";
}

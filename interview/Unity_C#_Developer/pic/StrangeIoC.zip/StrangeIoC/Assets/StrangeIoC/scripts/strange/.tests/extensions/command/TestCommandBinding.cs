using System;
using NUnit.Framework;
using strange.extensions.command.api;
using strange.extensions.command.impl;

namespace strange.unittests
{
	[TestFixture()]
	public class TestCommandBinding
	{
		[Test()]
		public void TestCase ()
		{

		}
	}
}


using System;
using NUnit.Framework;

namespace strange.unittests
{
	[TestFixture()]
	public class TestEventCommand
	{
		[Test()]
		public void TestCase ()
		{
		}
	}
}


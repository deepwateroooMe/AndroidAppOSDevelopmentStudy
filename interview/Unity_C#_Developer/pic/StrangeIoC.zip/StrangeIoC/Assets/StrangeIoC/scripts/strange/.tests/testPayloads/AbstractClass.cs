using System;

namespace strange.unittests
{
	abstract public class AbstractClass
	{
		//No constructor
	}
}


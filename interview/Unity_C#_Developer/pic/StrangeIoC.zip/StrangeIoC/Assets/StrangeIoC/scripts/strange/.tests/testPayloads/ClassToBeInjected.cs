using System;

namespace strange.unittests
{
	public class ClassToBeInjected
	{
		public ClassToBeInjected ()
		{
		}
	}
}


using System;
using strange.extensions.command.impl;

namespace strange.unittests
{
	public class CommandWithExecute : Command
	{
		public override void Execute ()
		{
			if (true)
			{

			}
		}
	}
}


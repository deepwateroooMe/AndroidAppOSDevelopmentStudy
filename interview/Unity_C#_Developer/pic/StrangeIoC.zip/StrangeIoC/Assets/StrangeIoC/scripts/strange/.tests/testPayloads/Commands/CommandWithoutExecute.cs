using System;
using strange.extensions.command.impl;

namespace strange.unittests
{
	public class CommandWithoutExecute : Command
	{
		public CommandWithoutExecute ()
		{
		}
	}
}


using System;

namespace strange.unittests
{
	public interface IAnotherSimpleInterface
	{
		string stringValue{ get; set;}
	}
}


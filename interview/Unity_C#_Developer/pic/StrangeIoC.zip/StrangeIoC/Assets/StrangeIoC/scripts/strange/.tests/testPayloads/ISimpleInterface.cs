using System;

namespace strange.unittests
{
	public interface ISimpleInterface
	{
		int intValue{ get; set;}
	}
}


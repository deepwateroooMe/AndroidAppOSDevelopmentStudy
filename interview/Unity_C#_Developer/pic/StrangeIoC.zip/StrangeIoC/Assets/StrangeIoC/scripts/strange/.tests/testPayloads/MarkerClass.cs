using System;

namespace strange.unittests
{
	public class MarkerClass
	{
		public MarkerClass ()
		{
		}
	}
}


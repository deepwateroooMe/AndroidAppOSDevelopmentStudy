using System;
using strange.extensions.sequencer.impl;

namespace strange.unittests
{
	public class SequenceCommandWithExecute : SequenceCommand
	{
		public override void Execute ()
		{
			if (true)
			{

			}
		}
	}
}


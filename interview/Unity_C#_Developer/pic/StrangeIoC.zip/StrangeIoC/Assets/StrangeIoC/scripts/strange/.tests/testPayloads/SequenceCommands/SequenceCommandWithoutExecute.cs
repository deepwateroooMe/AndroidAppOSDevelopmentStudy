using System;
using strange.extensions.sequencer.impl;

namespace strange.unittests
{
	public class SequenceCommandWithoutExecute : SequenceCommand
	{
		public SequenceCommandWithoutExecute ()
		{
		}
	}
}


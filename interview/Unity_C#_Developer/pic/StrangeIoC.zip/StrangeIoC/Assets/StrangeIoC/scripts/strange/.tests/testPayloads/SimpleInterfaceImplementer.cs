using System;

namespace strange.unittests
{
	public class SimpleInterfaceImplementer : ISimpleInterface
	{
		public int intValue{ get; set;}

		public SimpleInterfaceImplementer ()
		{
		}
	}
}


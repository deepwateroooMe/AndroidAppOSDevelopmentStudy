using System;

namespace strange.unittests
{
	public enum SomeEnum
	{
		ONE,
		TWO,
		THREE,
		FOUR
	}
}


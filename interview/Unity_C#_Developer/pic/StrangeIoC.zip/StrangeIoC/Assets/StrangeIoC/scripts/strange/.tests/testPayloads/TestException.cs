using System;

namespace strange.unittests
{
	public class TestException :Exception
	{
		public TestException ()
		{
		}
	}
}

